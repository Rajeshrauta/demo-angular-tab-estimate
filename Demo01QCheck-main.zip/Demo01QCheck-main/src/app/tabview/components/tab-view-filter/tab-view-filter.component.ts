import { Component } from '@angular/core';

@Component({
  selector: 'app-tab-view-filter',
  templateUrl: './tab-view-filter.component.html',
  styleUrls: ['./tab-view-filter.component.scss']
})
export class TabViewFilterComponent {

}
