import { Component } from '@angular/core';

@Component({
  selector: 'app-tab-view-header',
  templateUrl: './tab-view-header.component.html',
  styleUrls: ['./tab-view-header.component.scss']
})
export class TabViewHeaderComponent {

}
