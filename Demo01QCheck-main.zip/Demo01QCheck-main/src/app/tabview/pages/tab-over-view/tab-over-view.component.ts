import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-over-view',
  templateUrl: './tab-over-view.component.html',
  styleUrls: ['./tab-over-view.component.scss']
})
export class TabOverViewComponent implements OnInit {
  ngOnInit(): void {
  }

}

